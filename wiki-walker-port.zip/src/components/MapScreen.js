// src/components/MapScreen.js
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { fetchNearby } from '../services/wiki';
import { categorize, CATEGORY_COLORS, CATEGORY_ICONS } from '../data/categories';
import PoiCard from './PoiCard';
import { defaultTheme as T } from '../themes';

// Startregion: Allgäu (wie in der Web-Version). latitudeDelta ~ Zoom.
const DEFAULT_REGION = {
  latitude: 47.66119, longitude: 10.347, latitudeDelta: 0.06, longitudeDelta: 0.06,
};

export default function MapScreen() {
  const mapRef = useRef(null);
  const reqId = useRef(0);
  const [pois, setPois] = useState([]);
  const [selected, setSelected] = useState(null);
  const [saved, setSaved] = useState({}); // pageid -> poi (vorerst nur Sitzung)
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('bereit');

  const loadForRegion = useCallback(async (region) => {
    // latitudeDelta in Meter umrechnen (~111 km pro Grad), auf 200–10000 begrenzen
    const radius = Math.min(Math.max(Math.round((region.latitudeDelta / 2) * 111000), 200), 10000);
    const id = ++reqId.current;
    setLoading(true);
    setStatus('suche Orte …');
    try {
      const list = await fetchNearby(region.latitude, region.longitude, radius);
      if (id !== reqId.current) return; // veraltete Antwort verwerfen
      const withCat = list.map((p) => ({ ...p, cat: categorize(`${p.description} ${p.extract}`) }));
      setPois(withCat);
      setStatus(withCat.length ? `${withCat.length} Orte in Sicht` : 'hier nichts gefunden');
    } catch (e) {
      if (id === reqId.current) setStatus('Daten nicht erreichbar');
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  }, []);

  useEffect(() => { loadForRegion(DEFAULT_REGION); }, [loadForRegion]);

  const locate = async () => {
    setStatus('suche Standort …');
    const { status: perm } = await Location.requestForegroundPermissionsAsync();
    if (perm !== 'granted') { setStatus('Standort verweigert'); return; }
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    mapRef.current?.animateToRegion(
      { latitude: pos.coords.latitude, longitude: pos.coords.longitude, latitudeDelta: 0.02, longitudeDelta: 0.02 },
      700
    );
  };

  const toggleSave = (poi) =>
    setSaved((prev) => {
      const n = { ...prev };
      if (n[poi.pageid]) delete n[poi.pageid]; else n[poi.pageid] = poi;
      return n;
    });

  return (
    <View style={styles.root}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_DEFAULT}
        style={StyleSheet.absoluteFill}
        initialRegion={DEFAULT_REGION}
        onRegionChangeComplete={loadForRegion}
        showsUserLocation
        showsMyLocationButton={false}
        onPress={() => setSelected(null)}
      >
        {pois.map((p) => (
          <Marker
            key={p.pageid}
            coordinate={{ latitude: p.lat, longitude: p.lon }}
            onPress={() => setSelected(p)}
            tracksViewChanges={false}
          >
            <View style={[styles.pin, { backgroundColor: CATEGORY_COLORS[p.cat] }]}>
              {CATEGORY_ICONS[p.cat] ? (
                <MaterialCommunityIcons name={CATEGORY_ICONS[p.cat]} size={16} color="#fff" />
              ) : (
                <View style={styles.dot} />
              )}
            </View>
          </Marker>
        ))}
      </MapView>

      <View style={styles.statusChip}>
        {loading && <ActivityIndicator size="small" color={T.accent} style={{ marginRight: 7 }} />}
        <Text style={styles.statusText}>{status}</Text>
      </View>

      <TouchableOpacity style={styles.fab} onPress={locate} activeOpacity={0.85}>
        <MaterialCommunityIcons name="crosshairs-gps" size={24} color="#fff" />
      </TouchableOpacity>

      {selected && (
        <PoiCard
          poi={selected}
          isSaved={!!saved[selected.pageid]}
          onSave={() => toggleSave(selected)}
          onClose={() => setSelected(null)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.bg },
  pin: {
    width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: 'rgba(255,255,255,0.92)',
    shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 3, shadowOffset: { width: 0, height: 2 },
  },
  dot: { width: 9, height: 9, borderRadius: 5, backgroundColor: '#fff' },
  statusChip: {
    position: 'absolute', top: 58, alignSelf: 'center', flexDirection: 'row', alignItems: 'center',
    backgroundColor: T.surface2, borderColor: T.line, borderWidth: 1, borderRadius: 999,
    paddingHorizontal: 14, paddingVertical: 7,
    shadowColor: '#3a322a', shadowOpacity: 0.12, shadowRadius: 8, shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  statusText: { fontSize: 13, color: T.inkSoft, fontWeight: '500' },
  fab: {
    position: 'absolute', right: 18, bottom: 36, width: 54, height: 54, borderRadius: 27,
    backgroundColor: T.accent, alignItems: 'center', justifyContent: 'center',
    shadowColor: '#3a322a', shadowOpacity: 0.25, shadowRadius: 10, shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
});
