// App.js
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import MapScreen from './src/components/MapScreen';

export default function App() {
  return (
    <>
      <StatusBar style="dark" />
      <MapScreen />
    </>
  );
}
