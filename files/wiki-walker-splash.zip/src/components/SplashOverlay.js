// src/components/SplashOverlay.js
import React, { useEffect, useRef } from 'react';
import { StyleSheet, Animated, Dimensions } from 'react-native';

const FOOT = require('../../assets/footprints.png');
const MARK = require('../../assets/mark.png');
const SAGE = '#7c8a64';
const { width, height } = Dimensions.get('window');

export default function SplashOverlay({ onDone }) {
  const overlay = useRef(new Animated.Value(1)).current;
  const footOp = useRef(new Animated.Value(0)).current;
  const footY = useRef(new Animated.Value(22)).current;
  const markOp = useRef(new Animated.Value(0)).current;
  const markScale = useRef(new Animated.Value(0.9)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.timing(footOp, { toValue: 0.55, duration: 750, useNativeDriver: true }),
        Animated.timing(footY, { toValue: 0, duration: 750, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(markOp, { toValue: 1, duration: 320, useNativeDriver: true }),
        Animated.sequence([
          Animated.spring(markScale, { toValue: 1.14, friction: 4, tension: 90, useNativeDriver: true }),
          Animated.spring(markScale, { toValue: 1, friction: 5, tension: 80, useNativeDriver: true }),
        ]),
      ]),
      Animated.delay(380),
      Animated.timing(overlay, { toValue: 0, duration: 520, useNativeDriver: true }),
    ]).start(() => { if (onDone) onDone(); });
  }, []);

  return (
    <Animated.View style={[styles.fill, { opacity: overlay }]} pointerEvents="none">
      <Animated.Image
        source={FOOT}
        resizeMode="contain"
        style={[styles.foot, { opacity: footOp, transform: [{ translateY: footY }] }]}
      />
      <Animated.Image
        source={MARK}
        resizeMode="contain"
        style={[styles.mark, { opacity: markOp, transform: [{ scale: markScale }] }]}
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  fill: { ...StyleSheet.absoluteFillObject, backgroundColor: SAGE },
  foot: {
    position: 'absolute',
    bottom: height * 0.14,
    alignSelf: 'center',
    width: width * 0.86,
    height: width * 0.86 * 0.65,
  },
  mark: {
    position: 'absolute',
    top: height * 0.30,
    alignSelf: 'center',
    width: 112,
    height: 112,
  },
});
