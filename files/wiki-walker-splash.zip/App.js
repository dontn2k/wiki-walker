// App.js
import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import MapScreen from './src/components/MapScreen';
import SplashOverlay from './src/components/SplashOverlay';

export default function App() {
  const [ready, setReady] = useState(false);
  return (
    <>
      <StatusBar style="dark" />
      <MapScreen />
      {!ready && <SplashOverlay onDone={() => setReady(true)} />}
    </>
  );
}
