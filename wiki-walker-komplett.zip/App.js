// App.js
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import MapScreen from './src/components/MapScreen';

export default function App() {
  useFonts({ YoungSerif: require('./assets/fonts/YoungSerif.ttf') });
  return (
    <>
      <StatusBar style="dark" />
      <MapScreen />
    </>
  );
}
