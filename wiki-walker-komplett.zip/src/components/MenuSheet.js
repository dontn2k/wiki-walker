// src/components/MenuSheet.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, Pressable, ScrollView, Alert } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { defaultTheme as T } from '../themes';

function Row({ icon, label, sub, badge, onPress, disabled }) {
  return (
    <TouchableOpacity
      style={[styles.row, disabled && styles.rowDisabled]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.7}
    >
      <MaterialCommunityIcons name={icon} size={23} color={disabled ? T.inkSoft : T.sage} style={{ width: 28 }} />
      <View style={{ flex: 1 }}>
        <Text style={[styles.rowLabel, disabled && { color: T.inkSoft }]}>{label}</Text>
        {!!sub && <Text style={styles.rowSub}>{sub}</Text>}
      </View>
      {badge != null && <Text style={styles.badge}>{badge}</Text>}
    </TouchableOpacity>
  );
}

function Head({ title, onBack }) {
  return (
    <View style={styles.head}>
      <TouchableOpacity onPress={onBack} hitSlop={10}>
        <MaterialCommunityIcons name="chevron-left" size={26} color={T.inkSoft} />
      </TouchableOpacity>
      <Text style={styles.headTitle}>{title}</Text>
    </View>
  );
}

export default function MenuSheet({
  visible, onClose, lang, onLang, onLocate, saved, onShowSaved, onRemoveSaved,
  isTracking, guideOn, onToggleTour, onToggleGuide, onPlace,
  tours, onOpenTour, onRenameTour, onDeleteTour, headingUp, onToggleHeadingUp,
}) {
  const [view, setView] = useState('menu');
  const savedList = Object.entries(saved || {});
  const tourList = tours || [];
  const close = () => { setView('menu'); onClose(); };

  const fmtDate = (ms) => {
    const d = new Date(ms);
    return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }) + ' ' +
      d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  };
  const km = (m) => (m / 1000).toFixed(1).replace('.', ',') + ' km';
  const renameTour = (t) => {
    Alert.prompt(
      'Route umbenennen', null,
      [
        { text: 'Abbrechen', style: 'cancel' },
        { text: 'Speichern', onPress: (txt) => { if (txt && txt.trim()) onRenameTour(t.id, txt.trim()); } },
      ],
      'plain-text', t.name
    );
  };
  const confirmDelete = (t) => {
    Alert.alert('Route löschen?', t.name, [
      { text: 'Abbrechen', style: 'cancel' },
      { text: 'Löschen', style: 'destructive', onPress: () => onDeleteTour(t.id) },
    ]);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={close}>
      <Pressable style={styles.backdrop} onPress={close} />
      <View style={styles.sheet}>
        <View style={styles.handle} />

        {view === 'menu' && (
          <>
            <Row icon="crosshairs-gps" label="Standort finden" sub="Karte auf deine Position" onPress={() => { close(); onLocate(); }} />
            <Row icon="bookmark-outline" label="Gemerkte Orte" badge={savedList.length} onPress={() => setView('saved')} />
            <Row icon="cog-outline" label="Einstellungen" onPress={() => setView('settings')} />
            <View style={styles.divider} />
            <Row
              icon={isTracking ? 'stop-circle-outline' : 'map-marker-path'}
              label={isTracking ? 'Tour beenden' : 'Tour aufzeichnen'}
              sub={isTracking ? 'Aufzeichnung läuft' : 'Weg & vorbeigegangene Orte'}
              onPress={onToggleTour}
            />
            <Row
              icon={guideOn ? 'volume-high' : 'volume-medium'}
              label="Guide / Ansagen"
              sub={guideOn ? 'an – meldet Orte unterwegs' : 'aus'}
              onPress={onToggleGuide}
            />
            <Row
              icon="map-marker-plus"
              label="Eigener Punkt setzen"
              sub="Notiz, nur auf diesem Gerät"
              onPress={onPlace}
            />
          </>
        )}

        {view === 'saved' && (
          <View>
            <Head title="Gemerkte Orte" onBack={() => setView('menu')} />
            <ScrollView style={{ maxHeight: 360 }}>
              {savedList.length === 0 ? (
                <Text style={styles.empty}>Noch nichts gemerkt.{'\n'}Tippe in einem Ort auf „Merken".</Text>
              ) : (
                savedList.map(([id, p]) => (
                  <View key={id} style={styles.item}>
                    <Text style={styles.itemTitle}>{p.title}</Text>
                    {!!p.description && <Text style={styles.itemSub}>{p.description}</Text>}
                    <View style={styles.itemRow}>
                      <TouchableOpacity style={styles.itemBtn} onPress={() => { close(); onShowSaved(p); }}>
                        <Text style={styles.itemBtnTxt}>Auf Karte zeigen</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.itemBtn} onPress={() => onRemoveSaved(id)}>
                        <Text style={styles.itemBtnTxt}>Entfernen</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
              )}
            </ScrollView>
          </View>
        )}

        {view === 'settings' && (
          <View>
            <Head title="Einstellungen" onBack={() => setView('menu')} />
            <View style={styles.setRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.setLabel}>Sprache der Artikel</Text>
                <Text style={styles.setSub}>Wikipedia-Ausgabe</Text>
              </View>
              <View style={styles.seg}>
                {['de', 'en'].map((l) => (
                  <TouchableOpacity key={l} style={[styles.segBtn, lang === l && styles.segBtnOn]} onPress={() => onLang(l)}>
                    <Text style={[styles.segTxt, lang === l && styles.segTxtOn]}>{l.toUpperCase()}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.divider} />
            <Row
              icon="compass-outline"
              label="Karte dreht mit"
              sub={headingUp ? 'an – Blickrichtung oben' : 'aus – Norden oben'}
              onPress={onToggleHeadingUp}
            />
            <Row
              icon="history"
              label="Vergangene Touren"
              badge={tourList.length}
              onPress={() => setView('tours')}
            />
          </View>
        )}

        {view === 'tours' && (
          <View>
            <Head title="Vergangene Touren" onBack={() => setView('settings')} />
            <ScrollView style={{ maxHeight: 380 }}>
              {tourList.length === 0 ? (
                <Text style={styles.empty}>Noch keine Touren aufgezeichnet.{'\n'}Starte eine über „Tour aufzeichnen".</Text>
              ) : (
                tourList.map((t) => (
                  <View key={t.id} style={styles.item}>
                    <Text style={styles.itemTitle}>{t.name || 'Route'}</Text>
                    <Text style={styles.itemSub}>{fmtDate(t.start)} · {km(t.dist || 0)} · {(t.passed && t.passed.length) || 0} Orte</Text>
                    <View style={styles.itemRow}>
                      <TouchableOpacity style={styles.itemBtn} onPress={() => { setView('menu'); onOpenTour(t); }}>
                        <Text style={styles.itemBtnTxt}>Ansehen</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.itemBtn} onPress={() => renameTour(t)}>
                        <Text style={styles.itemBtnTxt}>Umbenennen</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.itemBtn} onPress={() => confirmDelete(t)}>
                        <Text style={styles.itemBtnTxt}>Löschen</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
              )}
            </ScrollView>
          </View>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(58,50,42,0.25)' },
  sheet: {
    backgroundColor: T.surface, borderTopLeftRadius: 22, borderTopRightRadius: 22,
    paddingHorizontal: 8, paddingBottom: 30,
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: T.line, alignSelf: 'center', marginVertical: 9 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, paddingHorizontal: 12, borderRadius: 13 },
  rowDisabled: { opacity: 0.55 },
  rowLabel: { fontSize: 15.5, fontWeight: '600', color: T.ink },
  rowSub: { fontSize: 12, color: T.inkSoft, marginTop: 1 },
  badge: { fontSize: 12, color: T.inkSoft, backgroundColor: T.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3, minWidth: 26, textAlign: 'center', overflow: 'hidden' },
  divider: { height: 1, backgroundColor: T.line, marginVertical: 6, marginHorizontal: 12 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 6, paddingVertical: 8 },
  headTitle: { fontSize: 18, fontWeight: '700', color: T.ink },
  empty: { color: T.inkSoft, textAlign: 'center', padding: 26, fontSize: 14, lineHeight: 20 },
  item: { borderWidth: 1, borderColor: T.line, borderRadius: 13, padding: 12, marginHorizontal: 12, marginVertical: 5, backgroundColor: T.surface2 },
  itemTitle: { fontSize: 15, fontWeight: '700', color: T.ink },
  itemSub: { fontSize: 12, color: T.inkSoft, marginTop: 1, marginBottom: 8 },
  itemRow: { flexDirection: 'row', gap: 7 },
  itemBtn: { flex: 1, borderWidth: 1, borderColor: T.line, borderRadius: 9, paddingVertical: 6, alignItems: 'center', backgroundColor: T.surface },
  itemBtnTxt: { fontSize: 12.5, color: T.ink },
  setRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 14 },
  setLabel: { fontSize: 14.5, fontWeight: '600', color: T.ink },
  setSub: { fontSize: 12, color: T.inkSoft, marginTop: 1 },
  seg: { flexDirection: 'row', borderWidth: 1, borderColor: T.line, borderRadius: 9, overflow: 'hidden' },
  segBtn: { paddingHorizontal: 14, paddingVertical: 7, backgroundColor: T.surface2 },
  segBtnOn: { backgroundColor: T.sage },
  segTxt: { fontSize: 13, color: T.ink },
  segTxtOn: { color: '#fff' },
  note: { fontSize: 12, color: T.inkSoft, paddingHorizontal: 12, paddingTop: 6, lineHeight: 18 },
});
